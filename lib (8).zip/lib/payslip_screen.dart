import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'main.dart'; // Import main.dart to access the User class

class PayslipScreen extends StatefulWidget {
  final User user; // Add User object to the constructor
  const PayslipScreen({super.key, required this.user});

  @override
  State<PayslipScreen> createState() => _PayslipScreenState();
}

class _PayslipScreenState extends State<PayslipScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // Check if the current user's position is 'ที่ปรึกษา'
    final bool isConsultant = widget.user.position == 'ที่ปรึกษา';

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'สลิปเงินเดือน', // Title for the Payslip screen
          style: GoogleFonts.kanit(),
        ),
        // Conditionally show the back button
        leading: isConsultant
            ? null // If consultant, hide the back button
            : IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.of(context)
                      .pop(); // This will pop the current screen off the stack
                },
              ),
        // Add the flexibleSpace with gradient to match the main app's AppBar
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Theme.of(context).colorScheme.primary.withOpacity(0.1),
                Colors.white
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
      ),
      // The Scaffold automatically uses the theme's scaffoldBackgroundColor
      // so no explicit backgroundColor property is needed here.
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.receipt_long_outlined,
                size: 80, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            Text(
              'หน้าสลิปเงินเดือน',
              style:
                  GoogleFonts.kanit(fontSize: 24, color: Colors.grey.shade600),
            ),
            Text(
              'กำลังอยู่ในระหว่างการพัฒนา', // ข้อความนี้จะยังอยู่บนหน้าจอหลัก
              style:
                  GoogleFonts.kanit(fontSize: 16, color: Colors.grey.shade500),
            ),
          ],
        ),
      ),
    );
  }
}
