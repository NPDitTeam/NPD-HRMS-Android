import 'package:flutter/material.dart';

import 'ui/app_theme.dart';

/// หน้า "อนุมัติ" บนแถบเมนูล่าง — รวมอนุมัติการลากับอนุมัติเพิ่มเวลาเป็นสองแท็บ
///
/// เดิมเป็นสองปุ่มแยกบนแถบเมนูล่าง ผู้อนุมัติจึงมี 6 ปุ่มจนตัวหนังสือเล็กและกดพลาดง่าย
///
/// ใช้ IndexedStack แทน TabBarView เพื่อให้ทั้งสองหน้าคงอยู่ตลอด — main.dart
/// สั่งรีเฟรชผ่าน GlobalKey ของแต่ละหน้า ถ้าหน้าถูกทิ้งตอนสลับแท็บ key จะว่าง
/// และการรีเฟรชจะหายไปเงียบ ๆ
class ApprovalsHubScreen extends StatefulWidget {
  const ApprovalsHubScreen({
    super.key,
    required this.leaveScreen,
    required this.addTimeScreen,
    this.pendingLeave = 0,
    this.pendingAddTime = 0,
    this.onTabTapped,
  });

  final Widget leaveScreen;
  final Widget addTimeScreen;
  final int pendingLeave;
  final int pendingAddTime;

  /// ผู้ใช้แตะแท็บ (0 = การลา, 1 = เพิ่มเวลา) — ใช้สั่งรีเฟรชหน้านั้น
  /// ไม่ถูกเรียกตอนสลับแท็บด้วยโค้ดผ่าน [ApprovalsHubScreenState.showTab]
  final ValueChanged<int>? onTabTapped;

  @override
  State<ApprovalsHubScreen> createState() => ApprovalsHubScreenState();
}

class ApprovalsHubScreenState extends State<ApprovalsHubScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  int get currentTab => _tabs.index;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this)..addListener(_onTabChanged);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  void _onTabChanged() {
    if (mounted) setState(() {});
  }

  /// เปิดแท็บที่ต้องการทันที ไม่เล่นแอนิเมชัน เพราะมักถูกเรียกตอนหน้านี้ยังไม่แสดง
  void showTab(int index) {
    if (index < 0 || index >= _tabs.length || index == _tabs.index) return;
    _tabs.index = index;
  }

  @override
  Widget build(BuildContext context) {
    final Color onAccent =
        AppColors.onAccent(Theme.of(context).colorScheme.primary);

    return Scaffold(
      appBar: AppGradientBar(
        title: const Text('อนุมัติคำขอ'),
        bottom: TabBar(
          controller: _tabs,
          onTap: widget.onTabTapped,
          // แท็บอยู่บนแถบหัวสีธีม จึงใช้สีตัวหนังสือของแถบหัว ไม่ใช่สีตามธีมปกติ
          labelColor: onAccent,
          unselectedLabelColor: onAccent.withValues(alpha: 0.7),
          indicatorColor: onAccent,
          dividerColor: Colors.transparent,
          tabs: [
            _tab('การลา', widget.pendingLeave),
            _tab('เพิ่มเวลา', widget.pendingAddTime),
          ],
        ),
      ),
      body: IndexedStack(
        index: _tabs.index,
        children: [widget.leaveScreen, widget.addTimeScreen],
      ),
    );
  }

  Widget _tab(String label, int count) {
    return Tab(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label),
          if (count > 0) ...[
            const SizedBox(width: 6),
            Badge.count(count: count, backgroundColor: AppColors.danger),
          ],
        ],
      ),
    );
  }
}
