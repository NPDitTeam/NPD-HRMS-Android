import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// สีกลางของแอป — แนว "พื้นขาวสะอาด"
///
/// พื้นหลังเป็นขาว/เทาอ่อนมาก สีขององค์กรใช้เป็นแค่สีเน้น (ปุ่มหลัก แถบเมนูที่เลือก)
/// เพราะแต่ละองค์กรตั้งสีเองได้ และสีอ่อนอย่างเหลือง NPD เอาไปทำตัวหนังสือ
/// บนพื้นขาวแล้วอ่านไม่ออก จึงต้องมี [ink] แยกไว้ใช้กับตัวหนังสือ/ไอคอน
class AppColors {
  AppColors._();

  static const Color background = Color(0xFFF6F7F9);
  static const Color surface = Colors.white;
  static const Color border = Color(0xFFE8EAEE);
  static const Color text = Color(0xFF1A1D21);
  static const Color textMuted = Color(0xFF6B7280);
  static const Color textFaint = Color(0xFF9CA3AF);
  static const Color success = Color(0xFF16A34A);
  static const Color danger = Color(0xFFDC2626);
  static const Color warning = Color(0xFFD97706);

  static bool _isDark(Color color) =>
      ThemeData.estimateBrightnessForColor(color) == Brightness.dark;

  /// สีตัวหนังสือบนพื้นสีองค์กร — ตัดสินจากความสว่างของสีจริง
  ///
  /// แทนกฎเดิม "เหลือง NPD = ดำ สีอื่น = ขาว" ซึ่งพังทันทีที่องค์กรตั้งสีอ่อน
  /// อย่างฟ้าอ่อนหรือเหลืองเฉดอื่น (ได้ตัวหนังสือขาวบนพื้นอ่อน)
  static Color onAccent(Color accent) => _isDark(accent) ? Colors.white : text;

  /// สีเน้นสำหรับตัวหนังสือ/ไอคอนที่วางบนพื้นขาว — สีองค์กรที่อ่อนเกินใช้สีเข้มแทน
  static Color ink(Color accent) => _isDark(accent) ? accent : text;

  /// พื้นอ่อนของสีองค์กร สำหรับพื้นไอคอน ป้าย และแถบที่ถูกเลือก
  static Color tint(Color accent, [double strength = 0.14]) =>
      Color.alphaBlend(accent.withValues(alpha: strength), Colors.white);

  /// สีกรอบการ์ด/เมนูทุกหน้า — สีองค์กรแบบอ่อน ผู้ใช้ขอให้กรอบเปลี่ยนตามธีม
  /// เข้มพอให้เห็นเป็นสีธีมแม้เป็นเหลือง แต่ไม่หนักตาเท่าสีเต็ม
  static Color frame(Color accent) => tint(accent, 0.4);

  /// สีเข้มขึ้นของสีธีม — ใช้ไล่เฉดบนแถบหัว
  static Color darken(Color color, [double amount = 0.14]) {
    final hsl = HSLColor.fromColor(color);
    return hsl
        .withLightness((hsl.lightness - amount).clamp(0.0, 1.0))
        .toColor();
  }

  /// ไอคอนแถบสถานะบนแถบหัวสีธีม — ขาวเมื่อสีเข้ม ดำเมื่อสีอ่อน (เช่นเหลือง NPD)
  static SystemUiOverlayStyle overlayStyleFor(Color accent) {
    final bool lightIcons = onAccent(accent) == Colors.white;
    return (lightIcons ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark)
        .copyWith(statusBarColor: Colors.transparent);
  }
}

/// ความมนของมุม — ใช้ชุดเดียวกันทั้งแอปให้หน้าตาไปทางเดียวกัน
class AppRadius {
  AppRadius._();

  static const double sm = 10;
  static const double md = 14;
  static const double lg = 18;
}

class AppTheme {
  AppTheme._();

  /// ธีมทั้งแอปจากสีขององค์กร (หรือสีที่ผู้ใช้เลือกเอง)
  static ThemeData light(Color accent) {
    final Color onAccent = AppColors.onAccent(accent);
    final Color ink = AppColors.ink(accent);

    // ใช้ fromSeed เพื่อได้โทนรองครบชุด แล้วทับด้วยค่าที่ต้องการจริง
    // พื้นผิวทุกระดับบังคับเป็นขาว/เทากลาง — ไม่งั้น Material 3 จะย้อมพื้นไดอะล็อก
    // ปฏิทิน และเมนู ตามสีองค์กร (ได้เหลืองอมเทา ฯลฯ)
    final ColorScheme scheme = ColorScheme.fromSeed(seedColor: accent).copyWith(
      primary: accent,
      onPrimary: onAccent,
      primaryContainer: AppColors.tint(accent, 0.22),
      onPrimaryContainer: AppColors.text,
      secondary: ink,
      onSecondary: AppColors.onAccent(ink),
      error: AppColors.danger,
      onError: Colors.white,
      surface: AppColors.surface,
      onSurface: AppColors.text,
      onSurfaceVariant: AppColors.textMuted,
      surfaceTint: Colors.transparent,
      surfaceContainerLowest: Colors.white,
      surfaceContainerLow: const Color(0xFFFAFAFB),
      surfaceContainer: AppColors.background,
      surfaceContainerHigh: Colors.white,
      surfaceContainerHighest: const Color(0xFFF1F3F5),
      outline: const Color(0xFFD1D5DB),
      outlineVariant: AppColors.border,
    );

    final ThemeData base = ThemeData(useMaterial3: true, colorScheme: scheme);

    TextStyle font(double size,
            {FontWeight weight = FontWeight.w500, Color? color}) =>
        GoogleFonts.ibmPlexSansThai(
            fontSize: size, fontWeight: weight, color: color);

    OutlineInputBorder inputBorder(Color color, [double width = 1]) =>
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: BorderSide(color: color, width: width),
        );

    final ButtonStyle primaryButton = ElevatedButton.styleFrom(
      backgroundColor: accent,
      foregroundColor: onAccent,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      textStyle: font(16, weight: FontWeight.w600),
    );

    return base.copyWith(
      scaffoldBackgroundColor: AppColors.background,
      textTheme: GoogleFonts.ibmPlexSansThaiTextTheme(base.textTheme)
          .apply(bodyColor: AppColors.text, displayColor: AppColors.text),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.text,
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: true,
        systemOverlayStyle: SystemUiOverlayStyle.dark
            .copyWith(statusBarColor: Colors.transparent),
        shape: const Border(bottom: BorderSide(color: AppColors.border)),
        iconTheme: const IconThemeData(color: AppColors.text),
        actionsIconTheme: const IconThemeData(color: AppColors.text),
        titleTextStyle: font(18, weight: FontWeight.w600, color: AppColors.text),
      ),
      cardTheme: CardThemeData(
        color: AppColors.surface,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
        elevation: 0,
        margin: const EdgeInsets.symmetric(vertical: 6),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.lg - 2),
          side: BorderSide(color: AppColors.frame(accent)),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(style: primaryButton),
      filledButtonTheme: FilledButtonThemeData(style: primaryButton),
      // ปุ่มตัวหนังสือเกือบทั้งแอปวางบนพื้นขาว (การ์ด/ไดอะล็อก) จึงใช้ ink
      // ห้ามใช้ onPrimary — เป็นสีขาวเมื่อสีองค์กรเข้ม ได้ขาวบนขาวมองไม่เห็น
      // (เคยเกิดกับปุ่ม "ดูไฟล์แนบ" ในหน้าอนุมัติ)
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: ink,
          textStyle: font(15, weight: FontWeight.w600),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.text,
          side: const BorderSide(color: Color(0xFFD1D5DB)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.md),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          textStyle: font(15, weight: FontWeight.w600),
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: accent,
        foregroundColor: onAccent,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.lg),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surface,
        // กรอบช่องกรอกข้อมูลเป็นสีธีมอ่อนเหมือนกรอบการ์ด ตอนพิมพ์เข้มขึ้นเป็น ink
        border: inputBorder(AppColors.frame(accent)),
        enabledBorder: inputBorder(AppColors.frame(accent)),
        disabledBorder: inputBorder(AppColors.border),
        focusedBorder: inputBorder(ink, 1.6),
        errorBorder: inputBorder(AppColors.danger),
        focusedErrorBorder: inputBorder(AppColors.danger, 1.6),
        labelStyle: font(15, color: AppColors.textMuted),
        floatingLabelStyle: font(15, color: ink),
        hintStyle:
            font(15, weight: FontWeight.w400, color: AppColors.textFaint),
        prefixIconColor: AppColors.textMuted,
        suffixIconColor: AppColors.textMuted,
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: accent,
        linearTrackColor: AppColors.tint(accent, 0.25),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1F2329),
        contentTextStyle: font(14, color: Colors.white),
        actionTextColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: AppColors.surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.lg + 2),
        ),
        titleTextStyle:
            font(18, weight: FontWeight.w600, color: AppColors.text),
        contentTextStyle:
            font(15, weight: FontWeight.w400, color: AppColors.text),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppColors.surface,
        modalBackgroundColor: AppColors.surface,
        surfaceTintColor: Colors.transparent,
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: AppColors.surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
        textStyle: font(15, color: AppColors.text),
      ),
      dividerTheme: const DividerThemeData(color: AppColors.border, thickness: 1),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        height: 68,
        indicatorColor: AppColors.tint(accent, 0.3),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        iconTheme: WidgetStateProperty.resolveWith(
          (states) => IconThemeData(
            size: 24,
            color: states.contains(WidgetState.selected)
                ? ink
                : AppColors.textMuted,
          ),
        ),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final bool selected = states.contains(WidgetState.selected);
          return font(
            12,
            weight: selected ? FontWeight.w600 : FontWeight.w500,
            color: selected ? AppColors.text : AppColors.textMuted,
          );
        }),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: AppColors.text,
        unselectedLabelColor: AppColors.textMuted,
        indicatorColor: accent,
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: AppColors.border,
        labelStyle: font(15, weight: FontWeight.w600),
        unselectedLabelStyle: font(15),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: AppColors.surface,
        selectedItemColor: ink,
        unselectedItemColor: AppColors.textMuted,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
        selectedLabelStyle: font(12, weight: FontWeight.w600),
        unselectedLabelStyle: font(11),
      ),
    );
  }
}

/// กล่องพื้นขาวขอบบาง — หน่วยพื้นฐานของหน้าจอแบบใหม่ (แทนการ์ดเงาหนาแบบเดิม)
class AppPanel extends StatelessWidget {
  const AppPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        side: BorderSide(
          color: AppColors.frame(Theme.of(context).colorScheme.primary),
        ),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

/// หัวข้อของแต่ละส่วนในหน้า พร้อมปุ่มลิงก์ด้านขวา (เช่น "ดูทั้งหมด")
class AppSectionHeader extends StatelessWidget {
  const AppSectionHeader(
    this.title, {
    super.key,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: GoogleFonts.ibmPlexSansThai(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.text,
              ),
            ),
          ),
          if (actionLabel != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                minimumSize: const Size(0, 32),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                visualDensity: VisualDensity.compact,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    actionLabel!,
                    style: GoogleFonts.ibmPlexSansThai(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded, size: 18),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// ป้ายสถานะเล็ก ๆ มีจุดสีนำหน้า เช่น "กำลังทำงาน" / "รออนุมัติ"
class AppStatusChip extends StatelessWidget {
  const AppStatusChip({super.key, required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: GoogleFonts.ibmPlexSansThai(
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

/// แถบหัวไล่เฉดสีธีม มุมล่างโค้ง — ใช้แทน AppBar ในทุกหน้าเมนู
///
/// ให้หน้าย่อยเป็นชุดเดียวกับหน้าแรก แต่สูงเท่าแถบหัวปกติ ไม่กินพื้นที่
/// รับพารามิเตอร์ชุดเดียวกับ AppBar เท่าที่แอปใช้จริง จึงเปลี่ยนได้โดยไม่ต้องแก้เนื้อหน้า
class AppGradientBar extends StatelessWidget implements PreferredSizeWidget {
  const AppGradientBar({
    super.key,
    this.title,
    this.actions,
    this.bottom,
    this.leading,
    this.centerTitle = true,
    this.automaticallyImplyLeading = true,
  });

  final Widget? title;
  final List<Widget>? actions;
  final PreferredSizeWidget? bottom;
  final Widget? leading;
  final bool centerTitle;
  final bool automaticallyImplyLeading;

  static const double _corner = 24;

  @override
  Size get preferredSize =>
      Size.fromHeight(kToolbarHeight + (bottom?.preferredSize.height ?? 0));

  @override
  Widget build(BuildContext context) {
    final Color accent = Theme.of(context).colorScheme.primary;
    final Color onAccent = AppColors.onAccent(accent);
    const BorderRadius radius =
        BorderRadius.vertical(bottom: Radius.circular(_corner));

    return AppBar(
      title: title,
      actions: actions,
      bottom: bottom,
      leading: leading,
      centerTitle: centerTitle,
      automaticallyImplyLeading: automaticallyImplyLeading,
      // สีจริงมาจาก flexibleSpace ด้านล่าง — ตัว AppBar จึงต้องโปร่งใส
      backgroundColor: Colors.transparent,
      foregroundColor: onAccent,
      iconTheme: IconThemeData(color: onAccent),
      actionsIconTheme: IconThemeData(color: onAccent),
      titleTextStyle: GoogleFonts.ibmPlexSansThai(
        color: onAccent,
        fontSize: 18,
        fontWeight: FontWeight.w600,
      ),
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: AppColors.overlayStyleFor(accent),
      shape: const RoundedRectangleBorder(borderRadius: radius),
      flexibleSpace: Container(
        decoration: BoxDecoration(
          borderRadius: radius,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [accent, AppColors.darken(accent)],
          ),
        ),
      ),
    );
  }
}
