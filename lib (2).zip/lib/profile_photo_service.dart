import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';

import 'odoo_rpc_service.dart';

/// รูปโปรไฟล์ของผู้ใช้ที่ล็อกอินอยู่
///
/// เก็บไว้ในหน่วยความจำชุดเดียว ทุกจอที่แสดงรูปฟังการเปลี่ยนแปลงจากที่นี่
/// ใช้ช่องเดียวกับรูปในทะเบียนพนักงานของ Odoo (employee.salary.employee_image)
/// พนักงานเปลี่ยนเองในแอปได้ และถ้าฝ่ายบุคคลเปลี่ยนให้ในระบบ แอปก็เห็นรูปใหม่เหมือนกัน
///
/// เขียนเข้า Odoo ตรง ๆ ผ่าน JSON-RPC ที่แอปใช้อยู่แล้ว ไม่ผ่าน PHP/MySQL
/// เพราะรูปพนักงานเป็นข้อมูลของ Odoo ฝั่งเดียว (ไม่ได้ซิงค์ไป MySQL)
class ProfilePhotoService extends ChangeNotifier {
  ProfilePhotoService._();

  static final ProfilePhotoService instance = ProfilePhotoService._();

  /// ไม่ต้องดึงรูปซ้ำทุกครั้งที่กลับมาหน้าแรก — รูปไม่ได้เปลี่ยนบ่อย
  static const Duration _minInterval = Duration(minutes: 5);

  Uint8List? _bytes;
  DateTime? _lastLoaded;
  bool _busy = false;
  String? _employeeCode;
  int? _employeeId;

  Uint8List? get bytes => _bytes;

  /// กำลังอัปโหลด/ลบรูปอยู่ — จอที่แสดงรูปเอาไว้ขึ้นวงหมุนทับ
  bool get busy => _busy;

  /// ผูกกับพนักงานที่ล็อกอินอยู่ — เครื่องเดียวใช้หลายคนได้ รูปคนเก่าต้องไม่ค้าง
  void bind(String? employeeCode) {
    final code = (employeeCode ?? '').trim();
    final next = code.isEmpty ? null : code;
    if (next == _employeeCode) return;
    _employeeCode = next;
    _employeeId = null;
    _bytes = null;
    _lastLoaded = null;
  }

  /// โหลดรูปจาก Odoo — [force] = โหลดใหม่แม้เพิ่งโหลดไป
  Future<void> load({bool force = false}) async {
    final code = _employeeCode;
    if (code == null) return;
    final last = _lastLoaded;
    if (!force &&
        last != null &&
        DateTime.now().difference(last) < _minInterval) {
      return;
    }
    _lastLoaded = DateTime.now();
    try {
      final rows = await OdooRpcService().searchRead(
        model: 'employee.salary',
        domain: [
          ['employee_code', '=', code]
        ],
        fields: ['id', 'employee_image'],
        limit: 1,
      );
      if (rows.isEmpty) {
        _bytes = null;
      } else {
        _employeeId = rows.first['id'] as int?;
        final raw = rows.first['employee_image'];
        _bytes = (raw is String && raw.isNotEmpty) ? base64Decode(raw) : null;
      }
      notifyListeners();
    } catch (e) {
      // เน็ตมีปัญหา — คงรูปเดิมไว้ก่อน ดีกว่าให้รูปหายไปเฉย ๆ
      debugPrint('โหลดรูปโปรไฟล์ไม่ได้: $e');
    }
  }

  /// เลือกรูปแล้วอัปโหลด — คืนข้อความผลลัพธ์ให้จอที่เรียกไปแสดง
  /// คืน null เมื่อผู้ใช้กดยกเลิกตั้งแต่หน้าเลือกรูป
  Future<String?> pickAndUpload(ImageSource source) async {
    final XFile? picked;
    try {
      picked = await ImagePicker().pickImage(
        source: source,
        // ย่อตั้งแต่ในเครื่อง — อัปโหลดเร็วขึ้นและตรงกับขนาดที่ Odoo เก็บอยู่แล้ว
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );
    } catch (e) {
      debugPrint('เลือกรูปไม่สำเร็จ: $e');
      return 'เปิดกล้อง/คลังภาพไม่ได้ กรุณาลองใหม่';
    }
    if (picked == null) return null;

    return _upload(await picked.readAsBytes());
  }

  /// เขียนรูปลงบัตรพนักงานใน Odoo แล้วอัพเดทรูปในแอป
  Future<String?> _upload(Uint8List bytes) async {
    _busy = true;
    notifyListeners();
    try {
      final id = await _employeeIdOf();
      if (id == null) return 'ไม่พบข้อมูลพนักงานในระบบ';
      await OdooRpcService().callKw(
        model: 'employee.salary',
        method: 'write',
        args: [
          [id],
          {'employee_image': base64Encode(bytes)}
        ],
      );
      _bytes = bytes;
      _lastLoaded = DateTime.now();
      return 'อัปเดตรูปโปรไฟล์แล้ว';
    } catch (e) {
      debugPrint('อัปโหลดรูปไม่สำเร็จ: $e');
      return 'อัปโหลดรูปไม่สำเร็จ กรุณาลองใหม่';
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  /// กู้รูปที่เลือกค้างไว้ (เฉพาะ Android)
  ///
  /// ระหว่างเปิดกล้อง/คลังภาพ แอปถูกพักไว้เบื้องหลัง ถ้าเครื่องหน่วยความจำไม่พอ
  /// ระบบจะปิดแอปทิ้ง ผลการเลือกรูปจึงไม่ถูกส่งกลับมา (ผู้ใช้เห็นว่า "เปลี่ยนรูปไม่ติด")
  /// Android เก็บผลไว้ให้ดึงทีหลังได้ — เรียกตอนกลับเข้าหน้าแรกทุกครั้ง
  Future<String?> retrieveLostPhoto() async {
    if (!Platform.isAndroid) return null;
    if (_employeeCode == null) return null;
    final LostDataResponse lost;
    try {
      lost = await ImagePicker().retrieveLostData();
    } catch (e) {
      debugPrint('ดึงรูปที่ค้างไว้ไม่ได้: $e');
      return null;
    }
    final file = lost.file;
    if (lost.isEmpty || file == null) return null;

    debugPrint('พบรูปที่เลือกค้างไว้ก่อนแอปถูกปิด — อัปโหลดต่อให้');
    return _upload(await file.readAsBytes());
  }

  /// ลบรูปโปรไฟล์ — กลับไปใช้ตัวอักษรย่อ
  Future<String?> remove() async {
    _busy = true;
    notifyListeners();
    try {
      final id = await _employeeIdOf();
      if (id == null) return 'ไม่พบข้อมูลพนักงานในระบบ';
      await OdooRpcService().callKw(
        model: 'employee.salary',
        method: 'write',
        args: [
          [id],
          {'employee_image': false}
        ],
      );
      _bytes = null;
      _lastLoaded = DateTime.now();
      return 'ลบรูปโปรไฟล์แล้ว';
    } catch (e) {
      debugPrint('ลบรูปไม่สำเร็จ: $e');
      return 'ลบรูปไม่สำเร็จ กรุณาลองใหม่';
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  /// ล้างรูปตอนออกจากระบบ — เครื่องเดียวใช้หลายคนได้ ห้ามให้รูปคนเก่าค้าง
  void clear() {
    _employeeCode = null;
    _employeeId = null;
    _bytes = null;
    _lastLoaded = null;
    notifyListeners();
  }

  Future<int?> _employeeIdOf() async {
    if (_employeeId != null) return _employeeId;
    final code = _employeeCode;
    if (code == null) return null;
    final rows = await OdooRpcService().searchRead(
      model: 'employee.salary',
      domain: [
        ['employee_code', '=', code]
      ],
      fields: ['id'],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    _employeeId = rows.first['id'] as int?;
    return _employeeId;
  }
}
