import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart'; // Corrected import
import 'package:http/http.dart' as http;
import 'dart:io';

class CheckinScreen extends StatefulWidget {
  final int userId;
  final bool isDemoUser; // เพิ่ม isDemoUser เข้ามา

  const CheckinScreen({
    super.key,
    required this.userId,
    this.isDemoUser = false, // กำหนดค่าเริ่มต้นเป็น false หากไม่ได้ระบุ
  });

  @override
  State<CheckinScreen> createState() => _CheckinScreenState();
}

class _CheckinScreenState extends State<CheckinScreen> {
  bool _isLoading = true;
  String? _errorMessage;
  Position? _currentPosition;
  Map<String, dynamic>? _checkinData;
  double? _distanceInMeters;

  GoogleMapController? _mapController;
  final Set<Circle> _circles = {};

  @override
  void initState() {
    super.initState();
    _initializeCheckin();
  }

  Future<void> _initializeCheckin() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      await _fetchCheckinStatus();
      _currentPosition = await _determinePosition();
      _calculateDistance();
      if (_mapController != null) {
        _updateMap();
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _fetchCheckinStatus() async {
    try {
      final url = Uri.parse(
          'https://npdhrms.com/api/api_checkin_status.php?user_id=${widget.userId}');
      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);
        if (decoded['status'] == 'success') {
          _checkinData = decoded['data'];
        } else {
          throw Exception(decoded['message'] ?? 'ไม่สามารถโหลดข้อมูลลงเวลา');
        }
      } else {
        throw Exception('รหัสสถานะ: ${response.statusCode}');
      }
    } on TimeoutException {
      throw Exception('⏱️ การเชื่อมต่อล่าช้าเกิน 10 วินาที');
    } on SocketException {
      throw Exception('🌐 ไม่มีอินเทอร์เน็ตหรือเซิร์ฟเวอร์ไม่ตอบสนอง');
    } catch (e) {
      throw Exception('❗ ${e.toString()}');
    }
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return Future.error('กรุณาเปิด GPS');

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('กรุณาอนุญาตให้เข้าถึงตำแหน่ง');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error('การเข้าถึงตำแหน่งถูกปฏิเสธถาวร');
    }

    return await Geolocator.getCurrentPosition();
  }

  void _calculateDistance() {
    if (_currentPosition == null || _checkinData == null) return;

    final targetLat =
        double.tryParse(_checkinData!['targetLat'].toString()) ?? 0;
    final targetLng =
        double.tryParse(_checkinData!['targetLng'].toString()) ?? 0;

    setState(() {
      _distanceInMeters = Geolocator.distanceBetween(
        _currentPosition!.latitude,
        _currentPosition!.longitude,
        targetLat,
        targetLng,
      );
    });
  }

  void _updateMap() {
    if (_checkinData == null) return;

    final targetLat =
        double.tryParse(_checkinData!['targetLat'].toString()) ?? 0;
    final targetLng =
        double.tryParse(_checkinData!['targetLng'].toString()) ?? 0;
    final allowedMeter =
        double.tryParse(_checkinData!['allowedMeter'].toString()) ?? 100;

    final branchLocation = LatLng(targetLat, targetLng);

    setState(() {
      _circles.clear();
      _circles.add(Circle(
        circleId: const CircleId('radius'),
        center: branchLocation,
        radius: allowedMeter,
        fillColor: Colors.green.withOpacity(0.2),
        strokeColor: Colors.green,
        strokeWidth: 2,
      ));
    });

    LatLng cameraTarget = branchLocation;
    if (_currentPosition != null) {
      cameraTarget =
          LatLng(_currentPosition!.latitude, _currentPosition!.longitude);
    }

    _mapController?.animateCamera(
      CameraUpdate.newLatLngZoom(cameraTarget, 16),
    );
  }

  Future<void> _performCheckin(String type) async {
    if (_currentPosition == null) {
      _showStatusDialog('❗ ไม่พบตำแหน่งปัจจุบัน', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final url =
          Uri.parse('https://npdhrms.com/api/api_checkin_save_test.php');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'user_id': widget.userId,
          'type': type,
          'lat': _currentPosition!.latitude,
          'lng': _currentPosition!.longitude,
        }),
      );

      final decoded = json.decode(response.body);
      if (decoded['status'] == 'success') {
        _showStatusDialog('✅ ${decoded['message']}');
        await _fetchCheckinStatus();
        _currentPosition = await _determinePosition();
        _calculateDistance();
        _updateMap();
      } else {
        throw Exception(decoded['message']);
      }
    } catch (e) {
      _showStatusDialog('❌ ${e.toString()}', isError: true);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showStatusDialog(String message, {bool isError = false}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          backgroundColor: isError ? Colors.red.shade50 : Colors.green.shade50,
          title: Row(
            children: [
              Icon(
                isError ? Icons.error_outline : Icons.check_circle_outline,
                color: isError ? Colors.red.shade700 : Colors.green.shade700,
                size: 30,
              ),
              const SizedBox(width: 10),
              Text(
                isError ? 'เกิดข้อผิดพลาด' : 'สำเร็จ',
                style: TextStyle(
                  color: isError ? Colors.red.shade700 : Colors.green.shade700,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          content: Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              color: isError ? Colors.red.shade900 : Colors.green.shade900,
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                'ตกลง',
                style: TextStyle(
                  color: isError ? Colors.red.shade700 : Colors.green.shade700,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    bool canCheckIn = false;
    bool canCheckOut = false;
    bool inRange = false;

    if (_checkinData != null && _distanceInMeters != null) {
      canCheckIn = _checkinData!['canCheckIn'] == true;
      canCheckOut = _checkinData!['canCheckOut'] == true;
      final allowed =
          double.tryParse(_checkinData!['allowedMeter'].toString()) ?? 100;
      inRange = _distanceInMeters! <= allowed;
    }

    LatLng initialLocation = const LatLng(13.7563, 100.5018);
    if (_checkinData != null) {
      try {
        initialLocation = LatLng(
          double.parse(_checkinData!['targetLat'].toString()),
          double.parse(_checkinData!['targetLng'].toString()),
        );
      } catch (_) {}
    }

    // กำหนดเงื่อนไขสำหรับการเปิดใช้งานปุ่ม
    // ถ้าเป็นผู้ใช้สาธิต (widget.isDemoUser) จะไม่สนใจ inRange แต่ยังคงสนใจ canCheckIn/canCheckOut
    // ถ้าไม่ใช่ผู้ใช้สาธิต จะสนใจทั้ง canCheckIn/canCheckOut และ inRange
    final bool enableCheckInButton =
        (widget.isDemoUser ? canCheckIn : (canCheckIn && inRange)) &&
            !_isLoading;
    final bool enableCheckOutButton =
        (widget.isDemoUser ? canCheckOut : (canCheckOut && inRange)) &&
            !_isLoading;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ลงเวลาเข้า-ออกงาน'),
      ),
      body: _isLoading && _checkinData == null
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(
                  child: Text(_errorMessage!,
                      style: const TextStyle(color: Colors.red)))
              : _buildBody(canCheckIn, canCheckOut, inRange, initialLocation),
    );
  }

  Widget _buildBody(
      bool canCheckIn, bool canCheckOut, bool inRange, LatLng initialLocation) {
    // กำหนดเงื่อนไขสำหรับการเปิดใช้งานปุ่ม
    // ถ้าเป็นผู้ใช้สาธิต (widget.isDemoUser) จะไม่สนใจ inRange แต่ยังคงสนใจ canCheckIn/canCheckOut
    // ถ้าไม่ใช่ผู้ใช้สาธิต จะสนใจทั้ง canCheckIn/canCheckOut และ inRange
    final bool enableCheckInButton =
        (widget.isDemoUser ? canCheckIn : (canCheckIn && inRange)) &&
            !_isLoading;
    final bool enableCheckOutButton =
        (widget.isDemoUser ? canCheckOut : (canCheckOut && inRange)) &&
            !_isLoading;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                  '👤 คุณ: ${_checkinData?['firstName']} ${_checkinData?['lastName']}',
                  style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 6),
              // แสดงข้อความ "โหมดสาธิต: ไม่จำกัดพื้นที่" หากเป็นผู้ใช้สาธิต
              if (widget.isDemoUser)
                Text('📍 โหมดสาธิต: ไม่จำกัดพื้นที่',
                    style: TextStyle(
                        fontSize: 16,
                        color: Colors.blue.shade700,
                        fontWeight: FontWeight.bold))
              else ...[
                // ใช้ spread operator (...) เพื่อรวม Widgets เข้าไปใน List
                Text(
                    '📍 ระยะจากสาขา: ${_distanceInMeters?.toStringAsFixed(0) ?? '-'} เมตร',
                    style: const TextStyle(fontSize: 16)),
                if (!inRange && _distanceInMeters != null)
                  const Text('(คุณอยู่นอกพื้นที่ที่กำหนด)',
                      style: TextStyle(color: Colors.red)),
              ],
            ],
          ),
        ),
        Expanded(
          child: GoogleMap(
            mapType: MapType.normal,
            initialCameraPosition: CameraPosition(
              target: initialLocation,
              zoom: 16,
            ),
            onMapCreated: (controller) {
              _mapController = controller;
              _updateMap();
            },
            circles: _circles,
            myLocationButtonEnabled: true,
            myLocationEnabled: true,
            markers: const {},
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                onPressed:
                    enableCheckInButton ? () => _performCheckin('in') : null,
                icon: const Icon(Icons.login),
                label: const Text('เข้างาน'),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white),
              ),
              ElevatedButton.icon(
                onPressed:
                    enableCheckOutButton ? () => _performCheckin('out') : null,
                icon: const Icon(Icons.logout),
                label: const Text('ออกงาน'),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red, foregroundColor: Colors.white),
              ),
            ],
          ),
        )
      ],
    );
  }
}
